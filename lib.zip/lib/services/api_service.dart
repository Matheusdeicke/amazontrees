import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:amazontrees/model/Especies.dart';

class ApiService {
  static const String apiUrl = 'http://127.0.0.1:8000/api/arvores';

  static Future<List<Arvore>> fetchEspecies(BuildContext context) async {
    try {
      final response = await http
          .get(Uri.parse(apiUrl))
          .timeout(Duration(seconds: 10), onTimeout: () {
        throw Exception("A requisição demorou muito. Verifique sua conexão.");
      });

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);

        if (jsonResponse['data'] is List) {
          return (jsonResponse['data'] as List)
              .map((json) => Arvore.fromJson(json))
              .toList();
        } else {
          throw Exception("Resposta inesperada da API.");
        }
      } else {
        throw Exception(
            "Erro ao buscar espécies: ${response.statusCode} - ${response.reasonPhrase}");
      }
    } catch (e) {
      // Deixe o controle de exibição do erro para o chamador (Tela)
      rethrow;
    }
  }
}
